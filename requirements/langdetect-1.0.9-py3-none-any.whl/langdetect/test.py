import json
import random
from langdetect.detector_factory import detect
from langdetect import DetectorFactory
import time
DetectorFactory.seed = 0


# 读取JSON文件
with open('labeled_questions3.json', 'r', encoding='utf-8') as json_file:
    labeled_questions = json.load(json_file)

random.shuffle(labeled_questions)

start_time = time.time()

# 初始化计数器
same_count = 0
count1 = 0
count2 = 0
# 遍历labeled_questions列表
for item in labeled_questions:
    question = item['question']
    #question = remove_english_characters(question)
    label = item['label']
    # 调用detect函数
    detect_result = detect(question)
    if detect_result == 'zh-cn' or detect_result =='zh-tw':
            count2 += 1
    else:
         print(detect_result)
        
    #print(detect_result)
    # 比较detect函数的返回值与label
    if detect_result == label:
        same_count += 1

end_time = time.time()
execution_time = end_time - start_time
print(f"landect预测对的个数：{same_count}")
#print(f"fasttext模型预测为zh的个数：{count1}")
print(f"landect预测为中文的个数：{count2}")
print(f"运行时间为：{execution_time}")